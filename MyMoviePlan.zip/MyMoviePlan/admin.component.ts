typescript
import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent {
  username: string;
  password: string;
  movieName: string;
  genre: string;
  language: string;
  description: string;
  price: number;
  showTime: string;
  movieId: number;

  constructor(private http: HttpClient, private router: Router) { }

  login() {
    this.http.post('/login', { username: this.username, password: this.password })
      .subscribe((response: any) => {
        if (response.success) {
          this.router.navigate(['/dashboard']);
        } else {
          alert('Invalid username or password');
        }
      });
  }

  addMovie() {
    this.http.post('/addMovie', {
      username: this.username,
      password: this.password,
      movieName: this.movieName,
      genre: this.genre,
      language: this.language,
      description: this.description,
      price: this.price,
      showTime: this.showTime
    })
    .subscribe((response: any) => {
      if (response.success) {
        alert('Movie added successfully');
      } else {
        alert('Failed to add movie');
      }
    });
  }

  removeMovie() {
    this.http.post('/removeMovie', {
      username: this.username,
      password: this.password,
      movieId: this.movieId
    })
    .subscribe((response: any) => {
      if (response.success) {
        alert('Movie removed successfully');
      } else {
        alert('Failed to remove movie');
      }
    });
  }
}


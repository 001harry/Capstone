# MyMoviePlan

MyMoviePlan is a dynamic and responsive web application for booking movie tickets online for different genres and languages. It is developed for NMS Cinemas, a chain of single screen theatres established in 2004.

## Features

- User Registration and Login
- Payment Gateway Integration
- Movie Search, Filter, and Sort
- Dynamic Data Handling
- Responsive and Compatible with Different Devices

## Technologies Used

- Database Management: MySQL and Oracle
- Backend Logic: Java Programming, NodeJS
- Frontend Development: JSP, Angular, Bootstrap, HTML/CSS, and Javascript
- Automation and Testing Technologies: Selenium, Jasmine, and TestNG
- DevOps and Production Technologies: Git, GitHub, Jenkins, Docker, Kubernetes, and AWS

## Project Structure

- `pom.xml`: Maven project object model file.
- `database.sql`: SQL script for creating the database and tables.
- `DatabaseConnection.java`: Java class for managing the database connection.
- `User.java`: Java class representing the User entity.
- `Admin.java`: Java class representing the Admin entity.
- `UserService.java`: Java class for handling user-related operations.
- `AdminController.java`: Java class for handling admin-related operations.
- `index.html`: The main HTML file for the frontend.
- `styles.css`: CSS file for styling the frontend.
- `main.js`: Javascript file for handling frontend logic.
- `user.component.html`: HTML file for the user component in Angular.
- `user.component.ts`: Typescript file for the user component in Angular.
- `admin.component.html`: HTML file for the admin component in Angular.
- `admin.component.ts`: Typescript file for the admin component in Angular.
- `test/UserTest.java`: JUnit test class for testing the User class.
- `test/AdminTest.java`: JUnit test class for testing the Admin class.
- `Dockerfile`: Dockerfile for creating a Docker image of the application.
- `Jenkinsfile`: Jenkinsfile for setting up the CI/CD pipeline.
- `.gitignore`: File specifying which files and directories to ignore in Git.
- `README.md`: This file.

## Setup and Run

1. Clone the repository
2. Navigate to the project directory: `cd MyMoviePlan`
3. Install dependencies: `mvn install`
4. Run the application: `mvn spring-boot:run`

## Testing

Run the tests with JUnit and Selenium: `mvn test`

## Deployment

The application is deployed on an AWS EC2 instance using Docker and Kubernetes.

## Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

## License

[MIT](https://choosealicense.com/licenses/mit/)

java
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Admin {

    private String username;
    private String password;

    public Admin(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public boolean login() {
        Connection connection = DatabaseConnection.getConnection();
        String query = "SELECT * FROM admins WHERE username = ? AND password = ?";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, this.username);
            preparedStatement.setString(2, this.password);
            ResultSet resultSet = preparedStatement.executeQuery();
            return resultSet.next();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseConnection.closeConnection();
        }
        return false;
    }

    public boolean addMovie(String movieName, String genre, String language, String description, double price, String showTime) {
        Connection connection = DatabaseConnection.getConnection();
        String query = "INSERT INTO movies (name, genre, language, description, price, show_time) VALUES (?, ?, ?, ?, ?, ?)";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, movieName);
            preparedStatement.setString(2, genre);
            preparedStatement.setString(3, language);
            preparedStatement.setString(4, description);
            preparedStatement.setDouble(5, price);
            preparedStatement.setString(6, showTime);
            int result = preparedStatement.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseConnection.closeConnection();
        }
        return false;
    }

    public boolean removeMovie(int movieId) {
        Connection connection = DatabaseConnection.getConnection();
        String query = "DELETE FROM movies WHERE id = ?";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, movieId);
            int result = preparedStatement.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseConnection.closeConnection();
        }
        return false;
    }

    public boolean updateMovie(int movieId, String movieName, String genre, String language, String description, double price, String showTime) {
        Connection connection = DatabaseConnection.getConnection();
        String query = "UPDATE movies SET name = ?, genre = ?, language = ?, description = ?, price = ?, show_time = ? WHERE id = ?";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, movieName);
            preparedStatement.setString(2, genre);
            preparedStatement.setString(3, language);
            preparedStatement.setString(4, description);
            preparedStatement.setDouble(5, price);
            preparedStatement.setString(6, showTime);
            preparedStatement.setInt(7, movieId);
            int result = preparedStatement.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseConnection.closeConnection();
        }
        return false;
    }
}


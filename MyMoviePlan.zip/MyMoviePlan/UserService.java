java
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserService {

    public User register(String username, String password, String email) {
        User user = new User(username, password, email);
        if (user.register()) {
            return user;
        }
        return null;
    }

    public User login(String username, String password) {
        User user = new User(username, password, null);
        if (user.login()) {
            return user;
        }
        return null;
    }

    public boolean updateEmail(User user, String newEmail) {
        Connection connection = DatabaseConnection.getConnection();
        String query = "UPDATE users SET email = ? WHERE username = ?";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, newEmail);
            preparedStatement.setString(2, user.getUsername());
            int result = preparedStatement.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseConnection.closeConnection();
        }
        return false;
    }

    public boolean deleteUser(User user) {
        Connection connection = DatabaseConnection.getConnection();
        String query = "DELETE FROM users WHERE username = ?";
        try {
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, user.getUsername());
            int result = preparedStatement.executeUpdate();
            return result > 0;
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DatabaseConnection.closeConnection();
        }
        return false;
    }
}


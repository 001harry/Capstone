-- Create database
CREATE DATABASE MyMoviePlan;

-- Use the created database
USE MyMoviePlan;

-- Create table for Users
CREATE TABLE Users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL,
    email VARCHAR(50),
    phone VARCHAR(15)
);

-- Create table for Admins
CREATE TABLE Admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL
);

-- Create table for Movies
CREATE TABLE Movies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    genre VARCHAR(50),
    language VARCHAR(50),
    description TEXT,
    show_time DATETIME,
    ticket_price DECIMAL(5,2),
    is_active BOOLEAN DEFAULT TRUE
);

-- Create table for Bookings
CREATE TABLE Bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    movie_id INT,
    booking_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES Users(id),
    FOREIGN KEY (movie_id) REFERENCES Movies(id)
);

-- Create table for Payments
CREATE TABLE Payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    booking_id INT,
    payment_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    amount DECIMAL(5,2),
    FOREIGN KEY (booking_id) REFERENCES Bookings(id)
);

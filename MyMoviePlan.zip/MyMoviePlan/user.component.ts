typescript
import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  username: string;
  email: string;
  searchKeyword: string;
  movies: any[] = [];
  cart: any[] = [];

  constructor(private userService: UserService) { }

  ngOnInit() {
    this.userService.getUserDetails().subscribe(data => {
      this.username = data.username;
      this.email = data.email;
    });
  }

  logout() {
    this.userService.logout().subscribe(() => {
      // Redirect to the login page
      window.location.href = '/login';
    });
  }

  searchMovies() {
    this.userService.searchMovies(this.searchKeyword).subscribe(data => {
      this.movies = data;
    });
  }

  addToCart(movie) {
    this.cart.push(movie);
  }

  removeFromCart(movie) {
    const index = this.cart.indexOf(movie);
    if (index > -1) {
      this.cart.splice(index, 1);
    }
  }

  checkout() {
    this.userService.checkout(this.cart).subscribe(() => {
      // Clear the cart
      this.cart = [];
      alert('Purchase successful!');
    });
  }
}


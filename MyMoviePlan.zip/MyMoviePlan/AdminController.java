java
import spark.Request;
import spark.Response;
import spark.Route;

public class AdminController {

    public static Route login = (Request request, Response response) -> {
        String username = request.queryParams("username");
        String password = request.queryParams("password");
        Admin admin = new Admin(username, password);
        if (admin.login()) {
            return "Login successful";
        } else {
            return "Invalid username or password";
        }
    };

    public static Route addMovie = (Request request, Response response) -> {
        String username = request.queryParams("username");
        String password = request.queryParams("password");
        Admin admin = new Admin(username, password);
        if (admin.login()) {
            String movieName = request.queryParams("movieName");
            String genre = request.queryParams("genre");
            String language = request.queryParams("language");
            String description = request.queryParams("description");
            double price = Double.parseDouble(request.queryParams("price"));
            String showTime = request.queryParams("showTime");
            if (admin.addMovie(movieName, genre, language, description, price, showTime)) {
                return "Movie added successfully";
            } else {
                return "Failed to add movie";
            }
        } else {
            return "Invalid username or password";
        }
    };

    public static Route removeMovie = (Request request, Response response) -> {
        String username = request.queryParams("username");
        String password = request.queryParams("password");
        Admin admin = new Admin(username, password);
        if (admin.login()) {
            int movieId = Integer.parseInt(request.queryParams("movieId"));
            if (admin.removeMovie(movieId)) {
                return "Movie removed successfully";
            } else {
                return "Failed to remove movie";
            }
        } else {
            return "Invalid username or password";
        }
    };

    public static Route updateMovie = (Request request, Response response) -> {
        String username = request.queryParams("username");
        String password = request.queryParams("password");
        Admin admin = new Admin(username, password);
        if (admin.login()) {
            int movieId = Integer.parseInt(request.queryParams("movieId"));
            String movieName = request.queryParams("movieName");
            String genre = request.queryParams("genre");
            String language = request.queryParams("language");
            String description = request.queryParams("description");
            double price = Double.parseDouble(request.queryParams("price"));
            String showTime = request.queryParams("showTime");
            if (admin.updateMovie(movieId, movieName, genre, language, description, price, showTime)) {
                return "Movie updated successfully";
            } else {
                return "Failed to update movie";
            }
        } else {
            return "Invalid username or password";
        }
    };
}


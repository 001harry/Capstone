// main.js

// Get the form elements
const loginForm = document.getElementById('login-form');
const registerForm = document.getElementById('register-form');

// Add event listeners for form submission
loginForm.addEventListener('submit', handleLogin);
registerForm.addEventListener('submit', handleRegister);

// Function to handle login
function handleLogin(event) {
    event.preventDefault();

    // Get form data
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    // Send a POST request to the server
    fetch('/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Redirect to the user dashboard
            window.location.href = '/dashboard';
        } else {
            // Show an error message
            alert('Invalid username or password');
        }
    });
}

// Function to handle registration
function handleRegister(event) {
    event.preventDefault();

    // Get form data
    const username = document.getElementById('reg-username').value;
    const password = document.getElementById('reg-password').value;
    const email = document.getElementById('reg-email').value;

    // Send a POST request to the server
    fetch('/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ username, password, email })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Redirect to the login page
            window.location.href = '/login';
        } else {
            // Show an error message
            alert('Registration failed');
        }
    });
}

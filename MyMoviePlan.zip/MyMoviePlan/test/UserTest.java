java
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UserTest {

    private User user;
    private UserService userService;

    @BeforeEach
    public void setUp() {
        userService = new UserService();
        user = userService.register("testUser", "testPassword", "testEmail@example.com");
    }

    @Test
    public void testRegister() {
        assertNotNull(user, "User registration failed");
    }

    @Test
    public void testLogin() {
        User loginUser = userService.login("testUser", "testPassword");
        assertNotNull(loginUser, "User login failed");
        assertEquals(user.getUsername(), loginUser.getUsername(), "Logged in user does not match registered user");
    }

    @Test
    public void testUpdateEmail() {
        boolean isUpdated = userService.updateEmail(user, "newEmail@example.com");
        assertTrue(isUpdated, "Email update failed");
    }

    @Test
    public void testDeleteUser() {
        boolean isDeleted = userService.deleteUser(user);
        assertTrue(isDeleted, "User deletion failed");
    }
}


java
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AdminTest {

    private Admin admin;

    @BeforeEach
    public void setUp() {
        admin = new Admin("admin", "password");
    }

    @Test
    public void testLogin() {
        assertTrue(admin.login());
    }

    @Test
    public void testAddMovie() {
        assertTrue(admin.addMovie("Movie1", "Genre1", "Language1", "Description1", 100.0, "ShowTime1"));
    }

    @Test
    public void testRemoveMovie() {
        assertTrue(admin.addMovie("Movie2", "Genre2", "Language2", "Description2", 200.0, "ShowTime2"));
        int movieId = 2; // Assuming the movieId for "Movie2" is 2
        assertTrue(admin.removeMovie(movieId));
    }

    @Test
    public void testUpdateMovie() {
        assertTrue(admin.addMovie("Movie3", "Genre3", "Language3", "Description3", 300.0, "ShowTime3"));
        int movieId = 3; // Assuming the movieId for "Movie3" is 3
        assertTrue(admin.updateMovie(movieId, "UpdatedMovie3", "UpdatedGenre3", "UpdatedLanguage3", "UpdatedDescription3", 400.0, "UpdatedShowTime3"));
    }
}

